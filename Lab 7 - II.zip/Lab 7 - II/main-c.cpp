#include <iostream>
#include <fstream>
#include <string>
#include <glad/gl.h>
#include <GLFW/glfw3.h>
#include <glm/glm.hpp>
#include <glm/ext/matrix_transform.hpp>
#include <glm/ext/matrix_clip_space.hpp>

GLuint loadShader(const std::string& filePath, GLenum shaderType) {
    GLuint shader = glCreateShader(shaderType);

    std::ifstream file(filePath);
    std::string sourceCode = std::string(std::istreambuf_iterator<char>(file), std::istreambuf_iterator<char>());
    const char* sourceCodeCStr = sourceCode.c_str();

    glShaderSource(shader, 1, &sourceCodeCStr, nullptr);
    glCompileShader(shader);

    GLint status;
    glGetShaderiv(shader, GL_COMPILE_STATUS, &status);
    if (!status) {
        GLint length;
        glGetShaderiv(shader, GL_INFO_LOG_LENGTH, &length);
        char *logStr = new char[length];
        glGetShaderInfoLog(shader, length, nullptr, logStr);
        std::cerr << "ERROR IN " << filePath << std::endl;
        std::cerr << logStr << std::endl;
        delete[] logStr;
        glDeleteShader(shader);
        return false;
    }

    return shader;
}

struct Color {
    uint8_t r, g, b, a;
};

struct Vertex {
    float x, y, z;
    uint8_t r, g, b, a;
    float s, t;
};

int main(int, char**) {
    
    if(!glfwInit()){
        std::cerr << "Failed to initialize GLFW" << std::endl;
        exit(-1);
    }

    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);  
    glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);

    GLFWwindow* window = glfwCreateWindow(800, 600, "Recursive Happiness with Transperancy", nullptr, nullptr);
    int W, H;
    glfwGetFramebufferSize(window, &W, &H);         // For compatibility with Retina.
    if(!window){
        std::cerr << "Failed to create window" << std::endl;
        glfwTerminate();
        exit(-1);
    }

    glfwMakeContextCurrent(window);

    gladLoadGL(glfwGetProcAddress);

    GLuint program = glCreateProgram();
    
    GLuint vs = loadShader("assets/shaders/simple.vert", GL_VERTEX_SHADER);
    glAttachShader(program, vs);
    glDeleteShader(vs);

    GLuint fs = loadShader("assets/shaders/alpha-test.frag", GL_FRAGMENT_SHADER);
    glAttachShader(program, fs);
    glDeleteShader(fs);

    glLinkProgram(program);

    GLint mvpLoc = glGetUniformLocation(program, "MVP");
    GLint samplerLoc = glGetUniformLocation(program, "tex_sampler");

    GLuint VAO;
    glGenVertexArrays(1, &VAO);
    glBindVertexArray(VAO);

    GLuint VBO;
    glGenBuffers(1, &VBO);
    glBindBuffer(GL_ARRAY_BUFFER, VBO);

    Vertex vertices[] = {
        {-0.5f, -0.5f, 0.0f,   0, 255, 255, 255, 0, 0},
        { 0.5f, -0.5f, 0.0f, 255,   0, 255, 255, 1, 0},
        { 0.5f,  0.5f, 0.0f, 255, 255,   0, 255, 1, 1},
        {-0.5f,  0.5f, 0.0f, 255,   0,   0, 255, 0, 1}
    };

    glBufferData(GL_ARRAY_BUFFER, 4*sizeof(Vertex), vertices, GL_STATIC_DRAW);

    GLint positionLoc = 0; 
    glEnableVertexAttribArray(positionLoc);
    glVertexAttribPointer(positionLoc, 3, GL_FLOAT, false, sizeof(Vertex), (void*)0);

    GLint colorLoc = 1;
    glEnableVertexAttribArray(colorLoc);
    glVertexAttribPointer(colorLoc, 4, GL_UNSIGNED_BYTE, true, sizeof(Vertex), (void*)offsetof(Vertex, r));

    GLint texCoordLoc = 2; 
    glEnableVertexAttribArray(texCoordLoc);
    glVertexAttribPointer(texCoordLoc, 2, GL_FLOAT, false, sizeof(Vertex), (void*)offsetof(Vertex, s));

    GLuint EBO;
    glGenBuffers(1, &EBO);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, EBO);

    uint16_t elements[] = {
        0, 1, 2,
        2, 3, 0
    };

    glBufferData(GL_ELEMENT_ARRAY_BUFFER, 6*sizeof(uint16_t), elements, GL_STATIC_DRAW);

    Color w = {255, 255, 255, 0}; // White
    Color Y = {255, 255, 0, 255}; // Yellow
    Color b = {0, 0, 0, 255}; // Black

    const int TEX_W = 8;
    const int TEX_H = 8;

    Color pixels[TEX_W*TEX_H] = {
        w, w, Y, Y, Y, Y, w, w, 
        w, Y, Y, b, b, Y, Y, w,
        Y, Y, b, Y, Y, b, Y, Y,
        Y, Y, Y, Y, Y, Y, Y, Y,
        Y, Y, b, Y, Y, b, Y, Y,
        Y, Y, b, Y, Y, b, Y, Y,
        w, Y, Y, Y, Y, Y, Y, w,
        w, w, Y, Y, Y, Y, w, w,
    };      
    // remove last column

    GLuint texture;
    glGenTextures(1, &texture);
    glBindTexture(GL_TEXTURE_2D, texture);
    glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, TEX_W, TEX_H, 0, GL_RGBA, GL_UNSIGNED_BYTE, (void*)pixels);
    glGenerateMipmap(GL_TEXTURE_2D);

    GLuint sampler;
    glGenSamplers(1, &sampler);
    glSamplerParameteri(sampler, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
    glSamplerParameteri(sampler, GL_TEXTURE_MIN_FILTER, GL_NEAREST_MIPMAP_LINEAR);

    glEnable(GL_DEPTH_TEST);
    glDepthFunc(GL_LESS);




    glEnable(GL_BLEND);
    glBlendEquation(GL_FUNC_ADD);       // will add
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);  //multiply by 


 
    // other solution is to disable depth mask.
    // not above render:
    // enable before clearing then disable in render loop
    // kan by3ml deoth testing 3ala buffer msh saleema.

    // 2nd problem: depth msh mazboot brdo
    // 7al wa7ed bas
    // sort before drawing (mn el ab3ad lel a2rab)
    // sort mn b3eed lel 2orayb to draw farther ones first.
    // el mohem howa el transparent hena.
    // 1 - draw all opaque objects 2 - sort transparent objects far to near 3 - draw transparent objects in order.

    // law 3ndna cube 3la b3do -> does not behave as 6 faces -> when we sort by object 
    // sorting within the cube won't be considered (byrsmhom bel order fel vertex buffer)
    // solved by disabling transparent depth write -> lesa mfeesh mshakl (+) bas dah afdal 7al:

    // Enable depth write -> clear
    // enable depth testing -> enable depth write -> draw all opaque
    // sort transparent far to end (projection kemto a3la 0 -> far)
    // draw them in that order
    // fy bardo problem with intersections wlakn dah afdal 7al

    // depth masking only ymna3 el transparent bas (enable then for opaque)
    // msh 3ayzeen transparent ytrsmo eal depth buffer


    // In the solution we did enable before clearing then disable in render loop -> all objects were transparent
    // by3tbr smiley face object 3ala b3do
    // 2flna bas el depth write msh el color write

    // el case el mo7adada elly hya 0 or 255 leha 7al ashal.
    // shader solution: if(frag_color.a < 0.5) discard
    // only works alpha mawgood aw msh mwgood.
    // no blending wala 7aha -> yersem bas elly el alpha msh b 0.
    // fel awal kan byrsom 7ata el alpha b 0.
    // hence case alpha = 0 or 1 not hard to deal with. (just threshold test.)
    // keda emsa7 el blending. salam.

    // depth mask: betkarar hal hasagel el object to be drawn on depth buffer or no
    // enable uses result to decide to decide or not.
    
    // recap:
    // to draw a transparent object:
    // enable depth write -> clear -> enable depth testing and writing -> drawe opaque -> disable depth writing
    // sort transparent far to near -> draw them in that order.
    // tayeb if we want to use alpha testing (like fg if condition) -> should we put with transparent or opaque?
    // m3 el opaque. (l2n ka2no opaque bas fy pixels we keep others we don't)
    // y3ny law 7aga leeha alpha testing -> 7otaha m3 el 7agatel opaque (no need to involve in sorting mess and such.)


    // other solutions msh hnshoof their implementation -> alpha to coverage
    // uses multisampling. law 7aga transparent 5azen shwya w shwya. shebh 7al. no need in project.

    // alpha testing != blending . law est5dmna testing haysheel kol el pixels elly a2al mn kmya mo7adada.

    //  other blending equations.
    // can multiply colors wara b3d badal add (msh far2 meen wara w meen 2odam in this case.)
    // src func = dst, dest func = 0
    // doesn't give all effects we may need.

    //b3d el eid lighting tutorial. only left for phase 3.

    




    // distination color is the last color in the color buffer.

    while(!glfwWindowShouldClose(window)){

        glClearColor(0.2f, 0.4f, 0.6f, 1.0f);
        glClearDepth(1.0);
        glDepthMask(true);
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
        //glDepthMask(false);

        glBindVertexArray(VAO);
        glUseProgram(program);

        glActiveTexture(GL_TEXTURE0);
        glBindTexture(GL_TEXTURE_2D, texture);
        glBindSampler(0, sampler);
        glUniform1i(samplerLoc, 0);
        
        float angle = (float)glfwGetTime();

        glm::vec3 eye = glm::vec3(2*glm::sin(angle), 1, 2*glm::cos(angle)); //glm::vec3(0, 0, 2); //

        glm::mat4 view = glm::lookAt(
            eye,
            glm::vec3(0, 0, 0),
            glm::vec3(0, 1, 0)
        );

        glm::mat4 projection = glm::perspective(
            glm::pi<float>()/2,
            W/float(H),
            0.01f,
            100.0f
        );

        for(int z = -1; z <= 1; z++){
            glm::mat4 MVP = projection * view * glm::translate(
                glm::mat4(1.0f),
                glm::vec3(0, 0, z)
            );
            glUniformMatrix4fv(mvpLoc, 1, false, (float*)&MVP);
            glDrawElements(GL_TRIANGLES, 6, GL_UNSIGNED_SHORT, (void*)0);
        }

        glfwSwapBuffers(window);
        glfwPollEvents();
    }

    glDeleteTextures(1, &texture);

    glfwDestroyWindow(window);
    glfwTerminate();
    return 0;
}
